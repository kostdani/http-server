#ifndef __PROGTEST__
#include <cassert>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <iostream>
#include <iomanip>
using namespace std;
#endif /* __PROGTEST__ */

using namespace std;

class CStrAuto
{
public:
    CStrAuto            (  );
    CStrAuto            ( const char * str);
    CStrAuto            ( const CStrAuto & x );
    ~CStrAuto            ( void ) noexcept;
    CStrAuto               & operator =          ( CStrAuto x );
    operator const char * ( void ) const;

    bool operator<(const CStrAuto &sec)const{
        return strcmp(m_Data->m_Str,sec.m_Data->m_Str)<0;
    }
    bool operator==(const CStrAuto &sec)const{
        return strcmp(m_Data->m_Str,sec.m_Data->m_Str)==0;

    }
private:
    struct TData
    {
        TData               ( const char * str,
                              int reserve );
        TData               ( const TData & src,
                              int reserve );
        ~TData               ( void );
        void                   Append              ( const char * src,
                                                     int srcLen );

        int                    m_RefCnt;
        int                    m_Len;
        int                    m_Max;
        char                 * m_Str;
    };

    TData                  * m_Data;



};


//=================================================================================================
CStrAuto::TData::TData        ( const char * str,
                                int reserve )
        : m_RefCnt ( 1 ),
          m_Len ( strlen ( str ) ),
          m_Max ( reserve ),
          m_Str ( new char[m_Max] )
{
    memcpy    ( m_Str, str, m_Len + 1 ); // + 1 = zero terminating character
}
//-------------------------------------------------------------------------------------------------
CStrAuto::TData::TData        ( const TData & src,
                                int reserve )
        : m_RefCnt ( 1 ),
          m_Len ( src . m_Len ),
          m_Max ( reserve ),
          m_Str ( new char[m_Max] )
{
    memcpy ( m_Str, src . m_Str, m_Len + 1 );
}
//-------------------------------------------------------------------------------------------------
CStrAuto::TData::~TData       ( void )
{
    delete [] m_Str;
}
//-------------------------------------------------------------------------------------------------
void              CStrAuto::TData::Append        ( const char * src,
                                                   int srcLen )
{
    if ( m_Len + srcLen + 1 > m_Max )
    {
        while (  m_Len + srcLen + 1 > m_Max )
            m_Max += m_Max < 100 ? 10 : m_Max / 2;

        char * tmp = new char [m_Max];
        memcpy ( tmp, m_Str, m_Len );
        memcpy ( tmp + m_Len, src, srcLen );
        delete [] m_Str;  // safe even if m_Str == src (can be the case of a += a)
        m_Str = tmp;
    }
    else
        memcpy ( m_Str + m_Len, src, srcLen );
    m_Len += srcLen;
    m_Str[m_Len] = 0;
}
//=================================================================================================
CStrAuto::CStrAuto            ()
{
    m_Data=new TData ( "",  1);
}
CStrAuto::CStrAuto            ( const char * str )
        : m_Data ( new TData ( str, strlen ( str ) + 1 ) )
{
}
//-------------------------------------------------------------------------------------------------
CStrAuto::CStrAuto            ( const CStrAuto & x )
        : m_Data ( x . m_Data )
{
    m_Data -> m_RefCnt ++;
}
//-------------------------------------------------------------------------------------------------
CStrAuto::~CStrAuto           ( void ) noexcept
{
        if (--m_Data->m_RefCnt == 0)
            delete m_Data;
}
//-------------------------------------------------------------------------------------------------
CStrAuto         & CStrAuto::operator =          ( CStrAuto x )
{
    swap ( m_Data, x . m_Data );
    return *this;
}
//-------------------------------------------------------------------------------------------------
CStrAuto::operator const char * ( void ) const
{
    return m_Data -> m_Str;
}




template <typename DT>
class MyVector{
public:
    MyVector(){
        arr=new DT[1]{};
        cap=1;
        len=0;
    }
    MyVector(const MyVector<DT>& orig){
        len=orig.len;
        cap=len;
        arr=new DT[cap]{};
        for (int i = 0; i < cap; ++i) {
            arr[i]=orig.arr[i];
        }
        //copy(orig.arr,orig.arr+len,arr);
    }
    MyVector<DT>& operator=(const MyVector<DT> & obj) {
        delete[] arr;
        cap=obj.len;
        len=cap;
        arr=new DT[cap]{};
        for (int i = 0; i < cap; ++i) {
            arr[i]=obj.arr[i];
        }
        //copy(obj.arr,obj.arr+len,arr);
        return *this;
    }
    ~MyVector(){
        delete[] arr;
    }
    size_t size() const{
        return len;
    }
    void push_back(const DT &val){
        if(len>=cap){
            cap*=2;
            DT *old=arr;
            arr = new DT[cap]{};
            copy(old,old+len,arr);
            delete[] old;
            //arr=(DT *)realloc(arr,sizeof(DT)*cap);
        }
        arr[len]=val;
        len++;
    }
    void pop_back(){
        if(len>0)
            len--;
    }
    DT &back(){
        return arr[len-1];
    }
    DT &operator[](int const& index){
        return arr[index];
    }
    DT &operator[](int const& index)const{
        return arr[index];
    }
    DT *arr;
private:
    int len;
    int cap;
};


template <typename DT>
class MySet{
private:
    unsigned int recFind(const DT& value,unsigned int start,unsigned int end) const{
        if(start==end) {
            //return start;
            if (array[start] < value)
                return start+1;
            else
                return start;
        }else{
            unsigned int mid=(start+end)/2;
            auto test=array[mid];
            if (array[mid] == value)
                return mid;
            else if(value < array[mid])
                return recFind(value,start,mid);
            else
                return recFind(value,mid+1,end);

        }


    }

public:
    MySet():array(){}
    MySet(const MySet &orig):array(orig.array){}
    MySet<DT> &operator=(const MySet<DT> &orig){
        array=orig.array;
        return *this;
    }
    MyVector<DT> array;
    void Insert(const DT& value){
        array.push_back(DT());//somnitelno
        for (int i = array.size()-1; i >0 ; --i) {
            if(value<array.arr[i-1]){
              //  memcpy(array.arr+i,array.arr+i-1,sizeof(DT));
                array[i]=array[i-1];
            }else{
                //memcpy(array.arr+i,(void*)*t,sizeof(DT));
                //array.arr[i]=0;
                array.arr[i]=value;
                return;
            }
        }
        array[0]=value;
        return;
    }
    unsigned int Find(const DT &value) const{
        if(!array.size())
            return 0;
        return recFind(value,0,array.size()-1);
    }
    void Remove(unsigned int pos){
        while (pos!=(array.size()-1)){
            array[pos]=array[pos+1];
            pos++;
        }
        array.pop_back();

    }
};

class FullName{
public:
    FullName():first(),second(){}
    FullName(const CStrAuto &n,const CStrAuto &s):first(n),second(s){}
    FullName(const FullName& orig):first(orig.first),second(orig.second){}
    FullName &operator=(const FullName& orig){
        if(this==&orig)
            return *this;
        first=orig.first;
        second=orig.second;
        return *this;
    }
    CStrAuto first;
    CStrAuto second;
};

class CCar{
public:
    CCar(){}
    CCar(const CStrAuto &RZ):rz(RZ){}
    CCar(const char *RZ):rz(RZ){}
    CCar(const CCar &orig){
        rz=orig.rz;
        owners=orig.owners;
    }
    CCar & operator =(const CCar &orig){
        rz=orig.rz;
        owners=orig.owners;
        return *this;
    }
    bool operator<(const CCar& sec)const{return rz<sec.rz;}
    bool operator==(const CCar& sec)const{return rz==sec.rz;}
    const char *RZ()const{
        return rz;
    }
    MyVector<FullName> owners;
private:
    CStrAuto rz;
};

class CCarList
{
public:
    // copy cons, op=, dtor ...
    CCarList(const MySet<CCar> *set,int pos){
        ptr=set;
        i=pos;
    }
    const char   * RZ           ( void ) const{
        return ptr->array[i].RZ();
    }
    bool           AtEnd        ( void ) const{
        return (size_t )i>=ptr->array.size();
    }
    void           Next         ( void ){
        int o=i;
        i++;
        while(!AtEnd()){
            if(!strcmp(ptr->array.arr[o].owners.back().first,ptr->array.arr[i].owners.back().first) && !strcmp(ptr->array.arr[o].owners.back().second,ptr->array.arr[i].owners.back().second))
                break;

            ++i;
        }
    }
private:
    const MySet<CCar> *ptr;
    int i;
    // todo
};

class COwnerList
{
public:
    COwnerList(MyVector<FullName> *vec,int pos){
        ptr=vec;
        i=pos;
    }
    // copy cons, op=, dtor ...
    const char   * Name         ( void ) const{
        return ptr->arr[i].first;
    }
    const char   * Surname      ( void ) const{
        return ptr->arr[i].second;
    }
    bool           AtEnd        ( void ) const{
        return i<0;
    }
    void           Next         ( void ){
        if(!AtEnd())
            --i;
    }
private:
    MyVector<FullName> *ptr;
    int i;
    // todo
};

class CRegister
{
public:
    CRegister(){}
    CRegister(const CRegister &orig):cars(orig.cars){}
    CRegister &operator =(CRegister &orig){
        if(this==&orig)
            return *this;
        cars=orig.cars;
        return *this;
    }
    // copy cons, op=, dtor ...
    bool           AddCar       ( const char      * rz,
                                  const char      * name,
                                  const char      * surname ){
        CStrAuto t(rz);
        auto it =cars.Find(t);
        if(it<cars.array.size()&&!strcmp(cars.array[it].RZ(),rz))
            return false;
        CCar c(t);
        c.owners.push_back(FullName(CStrAuto(name),CStrAuto(surname)));
        cars.Insert(c);
        return true;
    }
    bool           DelCar       ( const char      * rz ){
        CStrAuto t(rz);
        auto it =cars.Find(t);
        if(it>=cars.array.size()||strcmp(cars.array[it].RZ(),rz))
            return false;
        cars.Remove(it);
        return true;
    }
    bool           Transfer     ( const char      * rz,
                                  const char      * nName,
                                  const char      * nSurname ){
        CStrAuto t(rz);
        auto it =cars.Find(t);
        if(it>=cars.array.size()||strcmp(cars.array[it].RZ(),rz))
            return false;
        if(!strcmp(cars.array[it].owners.back().first,nName) && !strcmp(cars.array[it].owners.back().second,nSurname))
            return false;
        cars.array[it].owners.push_back(FullName(CStrAuto(nName),CStrAuto(nSurname)));
        return true;

    }
    CCarList       ListCars     ( const char      * name,
                                  const char      * surname ) const{
        if(!CountCars(name,surname))
            return CCarList(&cars,(int)cars.array.size());

        for(unsigned int i=0;i<cars.array.size();++i){
            if(!strcmp(cars.array.arr[i].owners.back().first,name) && !strcmp(cars.array[i].owners.back().second,surname))
                return CCarList(&cars,i);
        }
        return CCarList(&cars,(int)cars.array.size());
    }
    int            CountCars    ( const char      * name,
                                  const char      * surname ) const{
        int r=0;
        for (unsigned int i = 0; i < cars.array.size(); ++i) {
            if(!strcmp(cars.array[i].owners.back().first,name) && !strcmp(cars.array[i].owners.back().second,surname))
                ++r;
        }
        return r;
    }
    COwnerList     ListOwners   ( const char      * RZ ) const{
        auto it=cars.Find(CCar(CStrAuto(RZ)));
        if(it>=cars.array.size()||strcmp(cars.array[it].RZ(),RZ))
            return COwnerList(nullptr,-1);
        else{
            return COwnerList(&cars.array[it].owners,cars.array[it].owners.size()-1);
        }

    }
    int            CountOwners  ( const char      * RZ ) const{
        auto it=cars.Find(CCar(CStrAuto(RZ)));
        if(it>=cars.array.size()||strcmp(cars.array[it].RZ(),RZ))
            return 0;
        else{
            return cars.array[it].owners.size();
        }
    }
private:
    MySet<CCar> cars;
    // todo
};

#ifndef __PROGTEST__

static bool        matchList ( CCarList          && l,
                               const char         * rz1 = nullptr,
                               const char         * rz2 = nullptr )
{
    for ( ; ! l . AtEnd (); l . Next () )
        if ( rz1 && ! strcmp ( l . RZ (), rz1 ) )
            rz1 = nullptr;
        else if ( rz2 && ! strcmp ( l . RZ (), rz2 ) )
            rz2 = nullptr;
        else
            return false;
    return rz1 == nullptr && rz2 == nullptr;
}
int main ( void )
{
    char name[50], surname[50];
    CRegister  b0;
    assert ( b0 . AddCar ( "ABC-12-34", "John", "Smith" ) == true );
    strncpy ( name, "John", sizeof ( name ) );
    strncpy ( surname, "Hacker", sizeof ( surname ) );
    assert ( b0 . AddCar ( "ABC-32-22", name, surname ) == true );
    strncpy ( name, "Peter", sizeof ( name ) );
    strncpy ( surname, "Smith", sizeof ( surname ) );
    assert ( b0 . AddCar ( "XYZ-11-22", name, surname ) == true );

    assert ( b0 . CountCars ( "John", "Hacker" ) == 1 );

    assert ( matchList ( b0 . ListCars ( "John", "Hacker" ), "ABC-32-22" ) );
    assert ( b0 . CountOwners ( "ABC-12-34" ) == 1 );
    COwnerList ol0 = b0 . ListOwners ( "ABC-12-34" );
    assert ( ! ol0 . AtEnd () && ! strcmp ( ol0 . Name (), "John" ) && ! strcmp ( ol0 . Surname (), "Smith" ) );
    ol0 . Next ();
    assert ( ol0 . AtEnd () );
    CRegister b1 ( b0 );
    assert ( b0 . Transfer ( "XYZ-11-22", "John", "Hacker" ) == true );
    assert ( b0 . Transfer ( "XYZ-11-22", "Will", "Smith" ) == true );
    assert ( b1 . Transfer ( "XYZ-11-22", "John", "Smith" ) == true );
    assert ( b0 . CountOwners ( "XYZ-11-22" ) == 3 );


    COwnerList ol1 = b0 . ListOwners ( "XYZ-11-22" );
    assert ( ! ol1 . AtEnd () && ! strcmp ( ol1 . Name (), "Will" ) && ! strcmp ( ol1 . Surname (), "Smith" ) );
    ol1 . Next ();
    assert ( ! ol1 . AtEnd () && ! strcmp ( ol1 . Name (), "John" ) && ! strcmp ( ol1 . Surname (), "Hacker" ) );
    ol1 . Next ();
    assert ( ! ol1 . AtEnd () && ! strcmp ( ol1 . Name (), "Peter" ) && ! strcmp ( ol1 . Surname (), "Smith" ) );
    ol1 . Next ();
    assert ( ol1 . AtEnd () );

    assert ( b1 . CountOwners ( "XYZ-11-22" ) == 2 );
    COwnerList ol2 = b1 . ListOwners ( "XYZ-11-22" );
    assert ( ! ol2 . AtEnd () && ! strcmp ( ol2 . Name (), "John" ) && ! strcmp ( ol2 . Surname (), "Smith" ) );
    ol2 . Next ();
    assert ( ! ol2 . AtEnd () && ! strcmp ( ol2 . Name (), "Peter" ) && ! strcmp ( ol2 . Surname (), "Smith" ) );
    ol2 . Next ();
    assert ( ol2 . AtEnd () );
    b1 = b0;
    assert ( b0 . DelCar ( "XYZ-11-22" ) == true );
    assert ( b1 . DelCar ( "ABC-12-34" ) == true );
    assert ( b0 . CountCars ( "John", "Smith" ) == 1 );
    assert ( matchList ( b0 . ListCars ( "John", "Smith" ), "ABC-12-34" ) );
    assert ( b1 . CountCars ( "John", "Smith" ) == 0 );
    assert ( matchList ( b1 . ListCars ( "John", "Smith" ) ) );

    CRegister  b2;
    assert ( b2 . AddCar ( "ABC-12-34", "John", "Smith" ) == true );
    assert ( b2 . AddCar ( "ABC-32-22", "John", "Hacker" ) == true );
    assert ( b2 . AddCar ( "XYZ-11-22", "Peter", "Smith" ) == true );
    assert ( b2 . AddCar ( "XYZ-11-22", "Jane", "Black" ) == false );
    assert ( b2 . DelCar ( "AAA-11-11" ) == false );
    assert ( b2 . DelCar ( "XYZ-11-22" ) == true );
    assert ( b2 . Transfer ( "BBB-99-99", "John", "Smith" ) == false );
    assert ( b2 . Transfer ( "ABC-12-34", "John", "Smith" ) == false );
    assert ( b2 . Transfer ( "XYZ-11-22", "John", "Smith" ) == false );
    assert ( b2 . CountCars ( "George", "White" ) == 0 );
    assert ( matchList ( b2 . ListCars ( "George", "White" ) ) );
    assert ( b2 . CountOwners ( "AAA-AA-AA" ) == 0 );
    COwnerList ol3 = b2 . ListOwners ( "AAA-AA-AA" );
    assert ( ol3 . AtEnd () );

    return 0;
}
#endif /* __PROGTEST__ */
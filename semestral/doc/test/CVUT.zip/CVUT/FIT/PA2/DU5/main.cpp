#ifndef __PROGTEST__
#include <cassert>
#include <string>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <vector>
#include <set>
#include <list>
#include <map>
#include <algorithm>
using namespace std;

class CResult
{
public:
    CResult     ( const string & name,
                  unsigned int   studentID,
                  const string & test,
                  int            result )
            : m_Name ( name ),
              m_StudentID ( studentID ),
              m_Test ( test ),
              m_Result ( result )
    {
    }
    bool           operator == ( const CResult& other ) const
    {
        return m_Name == other . m_Name
               && m_StudentID == other . m_StudentID
               && m_Test == other . m_Test
               && m_Result == other . m_Result;
    }
    string         m_Name;
    unsigned int   m_StudentID;
    string         m_Test;
    int            m_Result;
};
#endif /* __PROGTEST__ */

bool compare_ID (const CResult& first, const CResult& second)
{
    return ( first.m_StudentID < second.m_StudentID );
}
bool compare_Name (const CResult& first, const CResult& second)
{
    return ( first.m_Name < second.m_Name );
}
bool compare_Result (const CResult& first, const CResult& second)
{
    return ( first.m_Result > second.m_Result );
}
class CTest{
public:
    set<unsigned int> registered;
    list<CResult> results;
    //map<unsigned int, int> results;
};

class CExam
{
public:
    static const int SORT_NONE   = 0;
    static const int SORT_ID     = 1;
    static const int SORT_NAME   = 2;
    static const int SORT_RESULT = 3;

    bool checkStudent(unsigned int id,const string& name){

        if(Students.find(id)!=Students.end() || tmp_Students.find(id)!=tmp_Students.end()){
            return false;
        }
        //cout<<id<<": "<<name<<endl;
        tmp_Students[id]=name;
        return true;
    }

    bool checkCard(const string &card, unsigned int id){
        if(Cards.find(card)!=Cards.end() || tmp_Cards.find(card)!=tmp_Cards.end()){
            return false;
        }
        //cout<<card<<" - "<<id<<endl;
        tmp_Cards[card]=id;
        return true;
    }

    bool LoadStudent(const string &line){
        stringstream str(line);
        string id,name;
        getline(str,id,':');
        size_t s;
        unsigned int intID=stoi(id,&s);
        if(s!=id.size())
            return false;
        getline(str,name,':');
        if(!checkStudent(intID,name))
            return false;
        while (!str.eof()){
            while(str.peek()==' ')
                str.ignore();
            string card;
            getline(str,card,',');
            while(card.back()==' ')
                card.pop_back();
            if(!checkCard(card,intID))
                return false;
        }
        return true;
    }
    bool           Load        ( istream      & cardMap ){
        while(!cardMap.eof()){
            string line;

            getline(cardMap,line);
            if(line.empty())
                break;
            if(!LoadStudent(line)){
                tmp_Students.clear();
                tmp_Cards.clear();
                return false;
            }
        }
        Students.insert(tmp_Students.begin(),tmp_Students.end());
        Cards.insert(tmp_Cards.begin(),tmp_Cards.end());
        tmp_Students.clear();
        tmp_Cards.clear();
        return true;
    }
    bool           Register    ( const string & cardID,
                                 const string & test ){
        auto it =Cards.find(cardID);
        if(it==Cards.end())
            return false;
        return Tests[test].registered.insert(it->second).second;
    }
    bool           Assess      ( unsigned int   studentID,
                                 const string & test,
                                 int            result ){
        if(Tests.find(test)==Tests.end())
            return false;
        auto it = Tests[test].registered.find(studentID);
        if(it==Tests[test].registered.end())
            return false;
        Tests[test].registered.erase(it);
        Tests[test].results.push_back(CResult(Students[studentID],studentID,test,result));
        return true;
    }
    list<CResult>  ListTest    ( const string & testName,
                                 int            sortBy ) const{
        auto it=Tests.find(testName);
        if(it==Tests.end())
            return list<CResult>();

        list<CResult> res=it->second.results;
        if(sortBy==SORT_NONE)
            return res;
        else if(sortBy==SORT_ID){
            res.sort(compare_ID);
            return res;
        }else if(sortBy==SORT_NAME){
            res.sort(compare_Name);
            return res;
        }else if(sortBy==SORT_RESULT){
            res.sort(compare_Result);
            return res;
        }
        return list<CResult>();

    }
    set<unsigned int> ListMissing ( const string & testName ) const{
        auto it=Tests.find(testName);
        if(it==Tests.end())
            return set<unsigned int>();
        return Tests.find(testName)->second.registered;
    }

private:
    map<string,CTest> Tests;
    map<unsigned int,string> Students;
    map<unsigned int,string> tmp_Students;
    map<string,unsigned int> Cards;
    map<string,unsigned int> tmp_Cards;

    // todo
};

#ifndef __PROGTEST__
int main ( void )
{
    istringstream iss;
    CExam         m;
    iss . clear ();
    iss . str ( "123456:Smith John:er34252456hjsd2451451, 1234151asdfe5123416, asdjklfhq3458235\n"
                "654321:Nowak Jane: 62wtsergtsdfg34\n"
                "456789:Nowak Jane: okjer834d34\n"
                "987:West Peter Thomas:sdswertcvsgncse\n" );
    assert ( m . Load ( iss ) );

    assert ( m . Register ( "62wtsergtsdfg34", "PA2 - #1" ) );
    assert ( m . Register ( "62wtsergtsdfg34", "PA2 - #2" ) );
    assert ( m . Register ( "er34252456hjsd2451451", "PA2 - #1" ) );
    assert ( m . Register ( "er34252456hjsd2451451", "PA2 - #3" ) );
    assert ( m . Register ( "sdswertcvsgncse", "PA2 - #1" ) );
    assert ( !m . Register ( "1234151asdfe5123416", "PA2 - #1" ) );
    assert ( !m . Register ( "aaaaaaaaaaaa", "PA2 - #1" ) );
    assert ( m . Assess ( 123456, "PA2 - #1", 50 ) );
    assert ( m . Assess ( 654321, "PA2 - #1", 30 ) );
    assert ( m . Assess ( 654321, "PA2 - #2", 40 ) );
    assert ( m . Assess ( 987, "PA2 - #1", 100 ) );
    assert ( !m . Assess ( 654321, "PA2 - #1", 35 ) );
    assert ( !m . Assess ( 654321, "PA2 - #3", 35 ) );
    assert ( !m . Assess ( 999999, "PA2 - #1", 35 ) );
   // auto lt=m . ListTest ( "PA2 - #1", CExam::SORT_RESULT);


    assert ( m . ListTest ( "PA2 - #1", CExam::SORT_RESULT ) == (list<CResult>
            {
                    CResult ( "West Peter Thomas", 987, "PA2 - #1", 100 ),
                    CResult ( "Smith John", 123456, "PA2 - #1", 50 ),
                    CResult ( "Nowak Jane", 654321, "PA2 - #1", 30 )
            } ) );
    assert ( m . ListTest ( "PA2 - #1", CExam::SORT_NAME ) == (list<CResult>
            {
                    CResult ( "Nowak Jane", 654321, "PA2 - #1", 30 ),
                    CResult ( "Smith John", 123456, "PA2 - #1", 50 ),
                    CResult ( "West Peter Thomas", 987, "PA2 - #1", 100 )
            } ) );
    assert ( m . ListTest ( "PA2 - #1", CExam::SORT_NONE ) == (list<CResult>
            {
                    CResult ( "Smith John", 123456, "PA2 - #1", 50 ),
                    CResult ( "Nowak Jane", 654321, "PA2 - #1", 30 ),
                    CResult ( "West Peter Thomas", 987, "PA2 - #1", 100 )
            } ) );
    assert ( m . ListTest ( "PA2 - #1", CExam::SORT_ID ) == (list<CResult>
            {
                    CResult ( "West Peter Thomas", 987, "PA2 - #1", 100 ),
                    CResult ( "Smith John", 123456, "PA2 - #1", 50 ),
                    CResult ( "Nowak Jane", 654321, "PA2 - #1", 30 )
            } ) );
    assert ( m . ListMissing ( "PA2 - #3" ) == (set<unsigned int>{ 123456 }) );
    iss . clear ();
    iss . str ( "888:Watson Joe:25234sdfgwer52, 234523uio, asdf234235we, 234234234\n" );
    assert ( m . Load ( iss ) );

    assert ( m . Register ( "234523uio", "PA2 - #1" ) );
    assert ( m . Assess ( 888, "PA2 - #1", 75 ) );
    iss . clear ();
    iss . str ( "555:Gates Bill:ui2345234sdf\n"
                "888:Watson Joe:2345234634\n" );
    assert ( !m . Load ( iss ) );

    assert ( !m . Register ( "ui2345234sdf", "PA2 - #1" ) );
    iss . clear ();
    iss . str ( "555:Gates Bill:ui2345234sdf\n"
                "666:Watson Thomas:okjer834d34\n" );
    assert ( !m . Load ( iss ) );

    assert ( !m . Register ( "ui2345234sdf", "PA2 - #3" ) );
    iss . clear ();
    iss . str ( "555:Gates Bill:ui2345234sdf\n"
                "666:Watson Thomas:jer834d3sdf4\n" );
    assert ( m . Load ( iss ) );

    assert ( m . Register ( "ui2345234sdf", "PA2 - #3" ) );
    assert ( m . ListMissing ( "PA2 - #3" ) == (set<unsigned int>{ 555, 123456 }) );

    return 0;
}
#endif /* __PROGTEST__ */

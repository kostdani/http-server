#ifndef __PROGTEST__
#include <cstdio>
#include <cstdlib>
#include <cstdint>
#include <cassert>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>
#include <vector>
#include <list>
#include <map>
#include <set>
#include <unordered_map>
#include <unordered_set>
#include <algorithm>
#include <memory>
#include <functional>
#include <stdexcept>
#include "ipaddress.h"
using namespace std;
#endif /* __PROGTEST__ */

class CRec{
public:
    CRec(const string &n):name(n){}
    string Name() const{return name;}
    virtual string Type()const{return "";}
    virtual void Print(ostream &os)const{os<<Name();}
    virtual bool operator == ( const CRec & x ) const {
        return Type()==x.Type()&&name==x.name;
    };

    virtual void Printf(ostream &os,string s)  const{os<<s;Print(os);}
protected:
    string name;
};

ostream &operator << (ostream &os,const CRec &r){
    r.Print(os);
    return os;
}

class CRecList{
public:
    vector<shared_ptr<CRec>> list;
    size_t Count()const{return list.size();}
    CRec & operator [] (size_t i){
        if(i>Count())
            throw out_of_range("Out of range");
        return *list[i];
    }
    CRec operator [] (size_t i) const{
        if(i>Count())
            throw out_of_range("Out of range");
        return *list[i];
    }
    void Print(ostream &os)const{
        for (size_t i = 0; i < list.size(); ++i) {
            list[i]->Print(os);
            if(list[i]->Type()!="CZone")
                os<< "\n";
        }
    }
    void Printf(ostream &os,string s)const{
        string p=s;
        p+="+- ";
        string e =s;
        e+="|  ";
        string f =s;
        f+="\\- ";
        for (size_t i = 0; i < list.size(); ++i) {
            if(list[i]->Type()!="CZone") {
                if (i == list.size() - 1)
                    list[i]->Printf(os, f);
                else
                    list[i]->Printf(os, p);
                os << "\n";
            }else{
                if (i == list.size() - 1) {
                    os << f << list[i]->Name() << "\n";
                    list[i]->Printf(os, s+="   ");

                }else{
                    os << p << list[i]->Name()<<"\n";
                    list[i]->Printf(os, e);
                }
            }
        }
    }


    bool Add(const shared_ptr<CRec> &ptr){
        for (size_t i = 0; i < list.size(); ++i) {
            if((*ptr)==(*list[i]))
                return false;
        }
        list.push_back(ptr);
        return true;
    }
    bool Del(const shared_ptr<CRec> &ptr){
        for (size_t i = 0; i < list.size(); ++i) {
            if((*ptr)==(*list[i])) {
                for (size_t j = i; j < list.size() - 1; ++j) {
                    list[j] = list[j + 1];
                }
                list.pop_back();
                return true;
            }
        }
        return false;
    }

};

ostream &operator << (ostream &os,const CRecList &l){
    l.Print(os);
    return os;
}

class CRecA : public CRec
{
public:
    // constructor
    CRecA(const string &n,const CIPv4 &ip): CRec(n),ipv4(ip){}
    CRecA(const CRecA &orig): CRec(orig.name),ipv4(orig.ipv4){}
    virtual bool operator == ( const CRec & x ) const override {
        return ((x.Type()=="CNAME"||x.Type()=="CZone") && name==x.Name())||(Type()==x.Type() && name == ((CRecA*)&x)->name && ipv4 == ((CRecA*)&x)->ipv4);
    }
    // Name ()
    // Type ()
    virtual string Type() const override{return "A";}
    // operator <<
    void Print(ostream &os)  const override{os << Name() << " " << Type() << " " << ipv4;}
    // todo
protected:
    CIPv4 ipv4;
};

class CRecAAAA : public CRec
{
public:
    // constructor
    CRecAAAA(const string &n,const CIPv6 &ip): CRec(n),ipv6(ip){}
    virtual bool operator == ( const CRec & x ) const override {
        return ((x.Type()=="CNAME"||x.Type()=="CZone") && name==x.Name())||(Type()==x.Type() && name == ((CRecAAAA*)&x)->name && ipv6 == ((CRecAAAA*)&x)->ipv6);
    }
    // Name ()
    // Type ()
    virtual string Type()  const override{return "AAAA";}
    // operator <<
    void Print(ostream &os)  const override{os << Name() << " " << Type() << " " << ipv6;}
    // todo
protected:
    CIPv6 ipv6;
};

class CRecMX : public CRec
{
public:
    // constructor
    CRecMX(const string &n,const string & mn,unsigned int p): CRec(n),mail(mn) {priority=p; }
    virtual bool operator == ( const CRec & x ) const override {
        return ((x.Type()=="CNAME"||x.Type()=="CZone") && name==x.Name())||(Type()==x.Type() && name == ((CRecMX*)&x)->name && mail == ((CRecMX*)&x)->mail && priority == ((CRecMX*)&x)->priority);
    }
    // Name ()
    // Type ()
    virtual string Type()  const override{return "MX";}
    // operator <<

    void Print(ostream &os)  const override{os << Name() << " " << Type() << " " << priority << " " << mail;}
    // todo
private:
    string mail;
    unsigned int priority;
};
class CRecSPF : public CRec
{
public:
    // constructor
    CRecSPF(const string &n): CRec(n) { }
    virtual bool operator == ( const CRec & x ) const override {
        return (x.Type()=="CNAME" && name==x.Name())||(Type()==x.Type() && name == x.Name());
    }
    // Name ()
    // Type ()
    virtual string Type()  const override{return "SPF";}
    // operator <<
    CRecSPF &Add(const string &nadr){
        adrs.push_back(nadr);
        return *this;
    }
    void Print(ostream &os)  const override{
        os << Name() << " " << Type() << " ";
        if(!adrs.empty())
            os<<adrs[0];
        for (int i = 1; i < adrs.size(); ++i) {
            os<<", "<<adrs[i];
        }
    }
    // todo
private:
    vector<string> adrs;
};
class CRecCNAME : public CRec
{
public:
    // constructor
    CRecCNAME(const string &n,const string & a): CRec(n), adr(a) { }
    virtual bool operator == ( const CRec & x ) const override {
        return name == x.Name();
    }
    // Name ()
    // Type ()
    virtual string Type()  const override{return "CNAME";}
    // operator <<

    void Print(ostream &os)  const override{os << Name() << " " << Type() << " " << adr ;}
    // todo
private:
    string adr;
};

class CZone : public CRec
{
public:
    // constructor(s)
    CZone(const string &n):CRec(n){}
    // destructor (if needed)
    // operator = (if needed)
    virtual bool operator == ( const CRec & x ) const override {
        return name == x.Name();
    }
    virtual string Type()  const override{return "CZone";}
    // Add ()
    bool Add(const CRec &newrec){
        if(newrec.Type()=="A")
            return Add(*((CRecA*)&newrec));
        else if(newrec.Type()=="AAAA")
            return Add(*((CRecAAAA*)&newrec));
        else if(newrec.Type()=="MX")
            return Add(*((CRecMX*)&newrec));
        else if(newrec.Type()=="CNAME")
            return Add(*((CRecCNAME*)&newrec));
        else if(newrec.Type()=="SPF")
            return Add(*((CRecSPF*)&newrec));
        else if(newrec.Type()=="CZone")
            return Add(*((CZone*)&newrec));
        else
            return false;
       // shared_ptr<CRec> r(new );
    }
    bool Add(const CRecA &newrec){
        shared_ptr<CRec> r= make_shared<CRecA>(newrec);
        return list.Add(r);
    }
    bool Add(const CRecAAAA &newrec){
        shared_ptr<CRec> r= make_shared<CRecAAAA>(newrec);
        return list.Add(r);
    }
    bool Add(const CRecMX &newrec){
        shared_ptr<CRec> r= make_shared<CRecMX>(newrec);
        return list.Add(r);
    }
    bool Add(const CRecSPF &newrec){
        shared_ptr<CRec> r= make_shared<CRecSPF>(newrec);
        return list.Add(r);
    }
    bool Add(const CRecCNAME &newrec){
        shared_ptr<CRec> r= make_shared<CRecCNAME>(newrec);
        return list.Add(r);
    }
    bool Add(const CZone &newrec){
        shared_ptr<CRec> r= make_shared<CZone>(newrec);
        return list.Add(r);
    }
    // Del ()
    bool Del(const CRecA &newrec){
        shared_ptr<CRec> r= make_shared<CRecA>(newrec);
        return list.Del(r);
    }
    bool Del(const CRecAAAA &newrec){
        shared_ptr<CRec> r= make_shared<CRecAAAA>(newrec);
        return list.Del(r);
    }
    bool Del(const CRecMX &newrec){
        shared_ptr<CRec> r= make_shared<CRecMX>(newrec);
        return list.Del(r);
    }
    bool Del(const CRecCNAME &newrec){
        shared_ptr<CRec> r= make_shared<CRecCNAME>(newrec);
        return list.Del(r);
    }
    bool Del(const CRecSPF &newrec){
        shared_ptr<CRec> r= make_shared<CRecSPF>(newrec);
        return list.Del(r);
    }
    bool Del(const CZone &newrec){
        shared_ptr<CRec> r= make_shared<CZone>(newrec);
        return list.Del(r);
    }
    // Search ()
    void Searchr(const vector<string> &samp,CRecList *r, size_t b) const{
        for (size_t i = 0; i < list.Count(); ++i) {
            if(list.list[i]->Name()==samp[b]){
                if(b==0)
                    r->Add(list.list[i]);
                else if(list.list[i]->Type()=="CZone") {
                    ((CZone *) (list.list[i].get()))->Searchr(samp, r,b-1);
                    return;
                }
            }
        }
    }
    CRecList Search(const string &samp) const{
        CRecList r;
        vector<string> adr;
        stringstream ss(samp);
        string n;
        while(getline(ss,n,'.')){
            adr.push_back(n);
        }

        Searchr(adr,&r,adr.size()-1);
//        Searchr(samp,&r);
        return r;
    }
    // operator <<
    void Print(ostream &os)  const override{
        os << name << "\n" ;
        list.Printf(os," ");
    }
    virtual void Printf(ostream &os,string s)  const override{
       // os << s<<name<<"\n";

        list.Printf(os,s);
    }
    // todo
    CRecList list;
private:
};

#ifndef __PROGTEST__
int main ( void )
{
    ostringstream oss;

    CZone z0 ( "fit" );
    assert ( z0 . Add ( CRecA ( "progtest", CIPv4 ( "147.32.232.142" ) ) ) == true );
    assert ( z0 . Add ( CRecAAAA ( "progtest", CIPv6 ( "2001:718:2:2902:0:1:2:3" ) ) ) == true );
    assert ( z0 . Add ( CRecA ( "courses", CIPv4 ( "147.32.232.158" ) ) ) == true );
    assert ( z0 . Add ( CRecA ( "courses", CIPv4 ( "147.32.232.160" ) ) ) == true );
    assert ( z0 . Add ( CRecA ( "courses", CIPv4 ( "147.32.232.159" ) ) ) == true );
    assert ( z0 . Add ( CRecCNAME ( "pririz", "sto.fit.cvut.cz." ) ) == true );
    assert ( z0 . Add ( CRecSPF ( "courses" ) . Add ( "ip4:147.32.232.128/25" ) . Add ( "ip4:147.32.232.64/26" ) ) == true );
    assert ( z0 . Add ( CRecAAAA ( "progtest", CIPv6 ( "2001:718:2:2902:1:2:3:4" ) ) ) == true );
    assert ( z0 . Add ( CRecMX ( "courses", "relay.fit.cvut.cz.", 0 ) ) == true );
    assert ( z0 . Add ( CRecMX ( "courses", "relay2.fit.cvut.cz.", 10 ) ) == true );
    oss . str ( "" );
    oss << z0;
    assert ( oss . str () ==
             "fit\n"
             " +- progtest A 147.32.232.142\n"
             " +- progtest AAAA 2001:718:2:2902:0:1:2:3\n"
             " +- courses A 147.32.232.158\n"
             " +- courses A 147.32.232.160\n"
             " +- courses A 147.32.232.159\n"
             " +- pririz CNAME sto.fit.cvut.cz.\n"
             " +- courses SPF ip4:147.32.232.128/25, ip4:147.32.232.64/26\n"
             " +- progtest AAAA 2001:718:2:2902:1:2:3:4\n"
             " +- courses MX 0 relay.fit.cvut.cz.\n"
             " \\- courses MX 10 relay2.fit.cvut.cz.\n" );
    assert ( z0 . Search ( "progtest" ) . Count () == 3 );
    oss . str ( "" );
    oss << z0 . Search ( "progtest" );
    assert ( oss . str () ==
             "progtest A 147.32.232.142\n"
             "progtest AAAA 2001:718:2:2902:0:1:2:3\n"
             "progtest AAAA 2001:718:2:2902:1:2:3:4\n" );
    assert ( z0 . Del ( CRecA ( "courses", CIPv4 ( "147.32.232.160" ) ) ) == true );
    assert ( z0 . Add ( CRecA ( "courses", CIPv4 ( "147.32.232.122" ) ) ) == true );
    oss . str ( "" );
    oss << z0;
    assert ( oss . str () ==
             "fit\n"
             " +- progtest A 147.32.232.142\n"
             " +- progtest AAAA 2001:718:2:2902:0:1:2:3\n"
             " +- courses A 147.32.232.158\n"
             " +- courses A 147.32.232.159\n"
             " +- pririz CNAME sto.fit.cvut.cz.\n"
             " +- courses SPF ip4:147.32.232.128/25, ip4:147.32.232.64/26\n"
             " +- progtest AAAA 2001:718:2:2902:1:2:3:4\n"
             " +- courses MX 0 relay.fit.cvut.cz.\n"
             " +- courses MX 10 relay2.fit.cvut.cz.\n"
             " \\- courses A 147.32.232.122\n" );
    assert ( z0 . Search ( "courses" ) . Count () == 6 );
    oss . str ( "" );
    oss << z0 . Search ( "courses" );
    assert ( oss . str () ==
             "courses A 147.32.232.158\n"
             "courses A 147.32.232.159\n"
             "courses SPF ip4:147.32.232.128/25, ip4:147.32.232.64/26\n"
             "courses MX 0 relay.fit.cvut.cz.\n"
             "courses MX 10 relay2.fit.cvut.cz.\n"
             "courses A 147.32.232.122\n" );
    oss . str ( "" );
    oss << z0 . Search ( "courses" ) [ 0 ];
    assert ( oss . str () == "courses A 147.32.232.158" );
    assert ( z0 . Search ( "courses" ) [ 0 ] . Name () == "courses" );
    assert ( z0 . Search ( "courses" ) [ 0 ] . Type () == "A" );
    oss . str ( "" );
    oss << z0 . Search ( "courses" ) [ 1 ];
    assert ( oss . str () == "courses A 147.32.232.159" );
    assert ( z0 . Search ( "courses" ) [ 1 ] . Name () == "courses" );
    assert ( z0 . Search ( "courses" ) [ 1 ] . Type () == "A" );
    oss . str ( "" );
    oss << z0 . Search ( "courses" ) [ 2 ];
    assert ( oss . str () == "courses SPF ip4:147.32.232.128/25, ip4:147.32.232.64/26" );
    assert ( z0 . Search ( "courses" ) [ 2 ] . Name () == "courses" );
    assert ( z0 . Search ( "courses" ) [ 2 ] . Type () == "SPF" );

    try
    {
        oss . str ( "" );
        oss << z0 . Search ( "courses" ) [ 10 ];
        assert ( "No exception thrown!" == nullptr );
    }
    catch ( const out_of_range & e )
    {
    }
    catch ( ... )
    {
        assert ( "Invalid exception thrown!" == nullptr );
    }
    dynamic_cast<const CRecAAAA &> ( z0 . Search ( "progtest" ) [ 1 ] );
    CZone z1 ( "fit2" );
    z1 . Add ( z0 . Search ( "progtest" ) [ 2 ] );
    z1 . Add ( z0 . Search ( "progtest" ) [ 0 ] );
    z1 . Add ( z0 . Search ( "progtest" ) [ 1 ] );
    z1 . Add ( z0 . Search ( "courses" ) [ 2 ] );
    oss . str ( "" );
    oss << z1;
    assert ( oss . str () ==
             "fit2\n"
             " +- progtest AAAA 2001:718:2:2902:1:2:3:4\n"
             " +- progtest A 147.32.232.142\n"
             " +- progtest AAAA 2001:718:2:2902:0:1:2:3\n"
             " \\- courses SPF ip4:147.32.232.128/25, ip4:147.32.232.64/26\n" );
    dynamic_cast<const CRecA &> ( z1 . Search ( "progtest" ) [ 1 ] );

    CZone z10 ( "fit" );
    assert ( z10 . Add ( CRecA ( "progtest", CIPv4 ( "147.32.232.142" ) ) ) == true );
    assert ( z10 . Add ( CRecAAAA ( "progtest", CIPv6 ( "2001:718:2:2902:0:1:2:3" ) ) ) == true );
    assert ( z10 . Add ( CRecA ( "progtest", CIPv4 ( "147.32.232.144" ) ) ) == true );
    assert ( z10 . Add ( CRecMX ( "progtest", "relay.fit.cvut.cz.", 10 ) ) == true );
    assert ( z10 . Add ( CRecA ( "progtest", CIPv4 ( "147.32.232.142" ) ) ) == false );
    assert ( z10 . Del ( CRecA ( "progtest", CIPv4 ( "147.32.232.140" ) ) ) == false );
    assert ( z10 . Del ( CRecA ( "progtest", CIPv4 ( "147.32.232.142" ) ) ) == true );
    assert ( z10 . Del ( CRecA ( "progtest", CIPv4 ( "147.32.232.142" ) ) ) == false );
    assert ( z10 . Add ( CRecMX ( "progtest", "relay.fit.cvut.cz.", 20 ) ) == true );
    assert ( z10 . Add ( CRecMX ( "progtest", "relay.fit.cvut.cz.", 10 ) ) == false );
    assert ( z10 . Add ( CRecCNAME ( "pririz", "sto.fit.cvut.cz." ) ) == true );
    assert ( z10 . Add ( CRecCNAME ( "pririz", "stojedna.fit.cvut.cz." ) ) == false );
    assert ( z10 . Add ( CRecA ( "pririz", CIPv4 ( "147.32.232.111" ) ) ) == false );
    assert ( z10 . Add ( CRecCNAME ( "progtest", "progtestbak.fit.cvut.cz." ) ) == false );
    assert ( z10 . Add ( CZone ( "test" ) ) == true );
    assert ( z10 . Add ( CZone ( "pririz" ) ) == false );
    assert ( z10 . Add ( CRecA ( "test", CIPv4 ( "147.32.232.232" ) ) ) == false );
    oss . str ( "" );
    oss << z10;
   // cout<<oss.str();
    assert ( oss . str () ==
             "fit\n"
             " +- progtest AAAA 2001:718:2:2902:0:1:2:3\n"
             " +- progtest A 147.32.232.144\n"
             " +- progtest MX 10 relay.fit.cvut.cz.\n"
             " +- progtest MX 20 relay.fit.cvut.cz.\n"
             " +- pririz CNAME sto.fit.cvut.cz.\n"
             " \\- test\n" );
    assert ( z10 . Search ( "progtest" ) . Count () == 4 );
    oss . str ( "" );
    oss << z10 . Search ( "progtest" );
    assert ( oss . str () ==
             "progtest AAAA 2001:718:2:2902:0:1:2:3\n"
             "progtest A 147.32.232.144\n"
             "progtest MX 10 relay.fit.cvut.cz.\n"
             "progtest MX 20 relay.fit.cvut.cz.\n" );
    assert ( z10 . Search ( "courses" ) . Count () == 0 );
    oss . str ( "" );
    oss << z10 . Search ( "courses" );
    assert ( oss . str () == "" );

    CZone z20 ( "<ROOT ZONE>" );
    CZone z21 ( "cz" );
    CZone z22 ( "cvut" );
    CZone z23 ( "fit" );
    assert ( z23 . Add ( CRecA ( "progtest", CIPv4 ( "147.32.232.142" ) ) ) == true );
    assert ( z23 . Add ( CRecAAAA ( "progtest", CIPv6 ( "2001:718:2:2902:0:1:2:3" ) ) ) == true );
    assert ( z23 . Add ( CRecA ( "courses", CIPv4 ( "147.32.232.158" ) ) ) == true );
    assert ( z23 . Add ( CRecA ( "courses", CIPv4 ( "147.32.232.160" ) ) ) == true );
    assert ( z23 . Add ( CRecA ( "courses", CIPv4 ( "147.32.232.159" ) ) ) == true );
    assert ( z23 . Add ( CRecCNAME ( "pririz", "sto.fit.cvut.cz." ) ) == true );
    assert ( z23 . Add ( CRecSPF ( "courses" ) . Add ( "ip4:147.32.232.128/25" ) . Add ( "ip4:147.32.232.64/26" ) ) == true );
    CZone z24 ( "fel" );
    assert ( z24 . Add ( CRecA ( "www", CIPv4 ( "147.32.80.2" ) ) ) == true );
    assert ( z24 . Add ( CRecAAAA ( "www", CIPv6 ( "1:2:3:4:5:6:7:8" ) ) ) == true );
    assert ( z22 . Add ( z23 ) == true );
    assert ( z22 . Add ( z24 ) == true );
    assert ( z21 . Add ( z22 ) == true );
    assert ( z20 . Add ( z21 ) == true );
    assert ( z23 . Add ( CRecA ( "www", CIPv4 ( "147.32.90.1" ) ) ) == true );
    oss . str ( "" );
    oss << z20;

    cout <<oss.str();
    assert ( oss . str () ==
             "<ROOT ZONE>\n"
             " \\- cz\n"
             "    \\- cvut\n"
             "       +- fit\n"
             "       |  +- progtest A 147.32.232.142\n"
             "       |  +- progtest AAAA 2001:718:2:2902:0:1:2:3\n"
             "       |  +- courses A 147.32.232.158\n"
             "       |  +- courses A 147.32.232.160\n"
             "       |  +- courses A 147.32.232.159\n"
             "       |  +- pririz CNAME sto.fit.cvut.cz.\n"
             "       |  \\- courses SPF ip4:147.32.232.128/25, ip4:147.32.232.64/26\n"
             "       \\- fel\n"
             "          +- www A 147.32.80.2\n"
             "          \\- www AAAA 1:2:3:4:5:6:7:8\n" );
    oss . str ( "" );
    oss << z21;
    assert ( oss . str () ==
             "cz\n"
             " \\- cvut\n"
             "    +- fit\n"
             "    |  +- progtest A 147.32.232.142\n"
             "    |  +- progtest AAAA 2001:718:2:2902:0:1:2:3\n"
             "    |  +- courses A 147.32.232.158\n"
             "    |  +- courses A 147.32.232.160\n"
             "    |  +- courses A 147.32.232.159\n"
             "    |  +- pririz CNAME sto.fit.cvut.cz.\n"
             "    |  \\- courses SPF ip4:147.32.232.128/25, ip4:147.32.232.64/26\n"
             "    \\- fel\n"
             "       +- www A 147.32.80.2\n"
             "       \\- www AAAA 1:2:3:4:5:6:7:8\n" );
    oss . str ( "" );
    oss << z22;
    assert ( oss . str () ==
             "cvut\n"
             " +- fit\n"
             " |  +- progtest A 147.32.232.142\n"
             " |  +- progtest AAAA 2001:718:2:2902:0:1:2:3\n"
             " |  +- courses A 147.32.232.158\n"
             " |  +- courses A 147.32.232.160\n"
             " |  +- courses A 147.32.232.159\n"
             " |  +- pririz CNAME sto.fit.cvut.cz.\n"
             " |  \\- courses SPF ip4:147.32.232.128/25, ip4:147.32.232.64/26\n"
             " \\- fel\n"
             "    +- www A 147.32.80.2\n"
             "    \\- www AAAA 1:2:3:4:5:6:7:8\n" );
    oss . str ( "" );
    oss << z23;
    assert ( oss . str () ==
             "fit\n"
             " +- progtest A 147.32.232.142\n"
             " +- progtest AAAA 2001:718:2:2902:0:1:2:3\n"
             " +- courses A 147.32.232.158\n"
             " +- courses A 147.32.232.160\n"
             " +- courses A 147.32.232.159\n"
             " +- pririz CNAME sto.fit.cvut.cz.\n"
             " +- courses SPF ip4:147.32.232.128/25, ip4:147.32.232.64/26\n"
             " \\- www A 147.32.90.1\n" );
    oss . str ( "" );
    oss << z24;
    assert ( oss . str () ==
             "fel\n"
             " +- www A 147.32.80.2\n"
             " \\- www AAAA 1:2:3:4:5:6:7:8\n" );
    auto sr=z20 . Search ( "progtest.fit.cvut.cz" );
    assert ( z20 . Search ( "progtest.fit.cvut.cz" ) . Count () == 2 );
    oss . str ( "" );
    oss << z20 . Search ( "progtest.fit.cvut.cz" );
    assert ( oss . str () ==
             "progtest A 147.32.232.142\n"
             "progtest AAAA 2001:718:2:2902:0:1:2:3\n" );
    assert ( z20 . Search ( "fit.cvut.cz" ) . Count () == 1 );
    oss . str ( "" );
    oss << z20 . Search ( "fit.cvut.cz" );
    assert ( oss . str () ==
             "fit\n"
             " +- progtest A 147.32.232.142\n"
             " +- progtest AAAA 2001:718:2:2902:0:1:2:3\n"
             " +- courses A 147.32.232.158\n"
             " +- courses A 147.32.232.160\n"
             " +- courses A 147.32.232.159\n"
             " +- pririz CNAME sto.fit.cvut.cz.\n"
             " \\- courses SPF ip4:147.32.232.128/25, ip4:147.32.232.64/26\n" );
    assert ( dynamic_cast<CZone &> ( z20 . Search ( "fit.cvut.cz" ) [0] ) . Add ( z20 . Search ( "fel.cvut.cz" ) [0] ) == true );
    oss . str ( "" );
    oss << z20;
    assert ( oss . str () ==
             "<ROOT ZONE>\n"
             " \\- cz\n"
             "    \\- cvut\n"
             "       +- fit\n"
             "       |  +- progtest A 147.32.232.142\n"
             "       |  +- progtest AAAA 2001:718:2:2902:0:1:2:3\n"
             "       |  +- courses A 147.32.232.158\n"
             "       |  +- courses A 147.32.232.160\n"
             "       |  +- courses A 147.32.232.159\n"
             "       |  +- pririz CNAME sto.fit.cvut.cz.\n"
             "       |  +- courses SPF ip4:147.32.232.128/25, ip4:147.32.232.64/26\n"
             "       |  \\- fel\n"
             "       |     +- www A 147.32.80.2\n"
             "       |     \\- www AAAA 1:2:3:4:5:6:7:8\n"
             "       \\- fel\n"
             "          +- www A 147.32.80.2\n"
             "          \\- www AAAA 1:2:3:4:5:6:7:8\n" );
   // return 0;
    assert ( dynamic_cast<CZone &> ( z20 . Search ( "fit.cvut.cz" ) [0] ) . Add ( z20 . Search ( "cz" ) [0] ) == true );
    oss . str ( "" );
    cout << z20;

    return 0;
    assert ( oss . str () ==
             "<ROOT ZONE>\n"
             " \\- cz\n"
             "    \\- cvut\n"
             "       +- fit\n"
             "       |  +- progtest A 147.32.232.142\n"
             "       |  +- progtest AAAA 2001:718:2:2902:0:1:2:3\n"
             "       |  +- courses A 147.32.232.158\n"
             "       |  +- courses A 147.32.232.160\n"
             "       |  +- courses A 147.32.232.159\n"
             "       |  +- pririz CNAME sto.fit.cvut.cz.\n"
             "       |  +- courses SPF ip4:147.32.232.128/25, ip4:147.32.232.64/26\n"
             "       |  +- fel\n"
             "       |  |  +- www A 147.32.80.2\n"
             "       |  |  \\- www AAAA 1:2:3:4:5:6:7:8\n"
             "       |  \\- cz\n"
             "       |     \\- cvut\n"
             "       |        +- fit\n"
             "       |        |  +- progtest A 147.32.232.142\n"
             "       |        |  +- progtest AAAA 2001:718:2:2902:0:1:2:3\n"
             "       |        |  +- courses A 147.32.232.158\n"
             "       |        |  +- courses A 147.32.232.160\n"
             "       |        |  +- courses A 147.32.232.159\n"
             "       |        |  +- pririz CNAME sto.fit.cvut.cz.\n"
             "       |        |  +- courses SPF ip4:147.32.232.128/25, ip4:147.32.232.64/26\n"
             "       |        |  \\- fel\n"
             "       |        |     +- www A 147.32.80.2\n"
             "       |        |     \\- www AAAA 1:2:3:4:5:6:7:8\n"
             "       |        \\- fel\n"
             "       |           +- www A 147.32.80.2\n"
             "       |           \\- www AAAA 1:2:3:4:5:6:7:8\n"
             "       \\- fel\n"
             "          +- www A 147.32.80.2\n"
             "          \\- www AAAA 1:2:3:4:5:6:7:8\n" );
    return 0;
    assert ( dynamic_cast<CZone &> ( z20 . Search ( "fit.cvut.cz.fit.cvut.cz" ) [0] ) . Add ( z20 . Search ( "cz" ) [0] ) == true );
    oss . str ( "" );
    oss << z20;
    assert ( oss . str () ==
             "<ROOT ZONE>\n"
             " \\- cz\n"
             "    \\- cvut\n"
             "       +- fit\n"
             "       |  +- progtest A 147.32.232.142\n"
             "       |  +- progtest AAAA 2001:718:2:2902:0:1:2:3\n"
             "       |  +- courses A 147.32.232.158\n"
             "       |  +- courses A 147.32.232.160\n"
             "       |  +- courses A 147.32.232.159\n"
             "       |  +- pririz CNAME sto.fit.cvut.cz.\n"
             "       |  +- courses SPF ip4:147.32.232.128/25, ip4:147.32.232.64/26\n"
             "       |  +- fel\n"
             "       |  |  +- www A 147.32.80.2\n"
             "       |  |  \\- www AAAA 1:2:3:4:5:6:7:8\n"
             "       |  \\- cz\n"
             "       |     \\- cvut\n"
             "       |        +- fit\n"
             "       |        |  +- progtest A 147.32.232.142\n"
             "       |        |  +- progtest AAAA 2001:718:2:2902:0:1:2:3\n"
             "       |        |  +- courses A 147.32.232.158\n"
             "       |        |  +- courses A 147.32.232.160\n"
             "       |        |  +- courses A 147.32.232.159\n"
             "       |        |  +- pririz CNAME sto.fit.cvut.cz.\n"
             "       |        |  +- courses SPF ip4:147.32.232.128/25, ip4:147.32.232.64/26\n"
             "       |        |  +- fel\n"
             "       |        |  |  +- www A 147.32.80.2\n"
             "       |        |  |  \\- www AAAA 1:2:3:4:5:6:7:8\n"
             "       |        |  \\- cz\n"
             "       |        |     \\- cvut\n"
             "       |        |        +- fit\n"
             "       |        |        |  +- progtest A 147.32.232.142\n"
             "       |        |        |  +- progtest AAAA 2001:718:2:2902:0:1:2:3\n"
             "       |        |        |  +- courses A 147.32.232.158\n"
             "       |        |        |  +- courses A 147.32.232.160\n"
             "       |        |        |  +- courses A 147.32.232.159\n"
             "       |        |        |  +- pririz CNAME sto.fit.cvut.cz.\n"
             "       |        |        |  +- courses SPF ip4:147.32.232.128/25, ip4:147.32.232.64/26\n"
             "       |        |        |  +- fel\n"
             "       |        |        |  |  +- www A 147.32.80.2\n"
             "       |        |        |  |  \\- www AAAA 1:2:3:4:5:6:7:8\n"
             "       |        |        |  \\- cz\n"
             "       |        |        |     \\- cvut\n"
             "       |        |        |        +- fit\n"
             "       |        |        |        |  +- progtest A 147.32.232.142\n"
             "       |        |        |        |  +- progtest AAAA 2001:718:2:2902:0:1:2:3\n"
             "       |        |        |        |  +- courses A 147.32.232.158\n"
             "       |        |        |        |  +- courses A 147.32.232.160\n"
             "       |        |        |        |  +- courses A 147.32.232.159\n"
             "       |        |        |        |  +- pririz CNAME sto.fit.cvut.cz.\n"
             "       |        |        |        |  +- courses SPF ip4:147.32.232.128/25, ip4:147.32.232.64/26\n"
             "       |        |        |        |  \\- fel\n"
             "       |        |        |        |     +- www A 147.32.80.2\n"
             "       |        |        |        |     \\- www AAAA 1:2:3:4:5:6:7:8\n"
             "       |        |        |        \\- fel\n"
             "       |        |        |           +- www A 147.32.80.2\n"
             "       |        |        |           \\- www AAAA 1:2:3:4:5:6:7:8\n"
             "       |        |        \\- fel\n"
             "       |        |           +- www A 147.32.80.2\n"
             "       |        |           \\- www AAAA 1:2:3:4:5:6:7:8\n"
             "       |        \\- fel\n"
             "       |           +- www A 147.32.80.2\n"
             "       |           \\- www AAAA 1:2:3:4:5:6:7:8\n"
             "       \\- fel\n"
             "          +- www A 147.32.80.2\n"
             "          \\- www AAAA 1:2:3:4:5:6:7:8\n" );
    assert ( dynamic_cast<CZone &> ( z20 . Search ( "fit.cvut.cz.fit.cvut.cz" ) [0] ) . Del ( CZone ( "fel" ) ) == true );
    oss . str ( "" );
    oss << z20;
    assert ( oss . str () ==
             "<ROOT ZONE>\n"
             " \\- cz\n"
             "    \\- cvut\n"
             "       +- fit\n"
             "       |  +- progtest A 147.32.232.142\n"
             "       |  +- progtest AAAA 2001:718:2:2902:0:1:2:3\n"
             "       |  +- courses A 147.32.232.158\n"
             "       |  +- courses A 147.32.232.160\n"
             "       |  +- courses A 147.32.232.159\n"
             "       |  +- pririz CNAME sto.fit.cvut.cz.\n"
             "       |  +- courses SPF ip4:147.32.232.128/25, ip4:147.32.232.64/26\n"
             "       |  +- fel\n"
             "       |  |  +- www A 147.32.80.2\n"
             "       |  |  \\- www AAAA 1:2:3:4:5:6:7:8\n"
             "       |  \\- cz\n"
             "       |     \\- cvut\n"
             "       |        +- fit\n"
             "       |        |  +- progtest A 147.32.232.142\n"
             "       |        |  +- progtest AAAA 2001:718:2:2902:0:1:2:3\n"
             "       |        |  +- courses A 147.32.232.158\n"
             "       |        |  +- courses A 147.32.232.160\n"
             "       |        |  +- courses A 147.32.232.159\n"
             "       |        |  +- pririz CNAME sto.fit.cvut.cz.\n"
             "       |        |  +- courses SPF ip4:147.32.232.128/25, ip4:147.32.232.64/26\n"
             "       |        |  \\- cz\n"
             "       |        |     \\- cvut\n"
             "       |        |        +- fit\n"
             "       |        |        |  +- progtest A 147.32.232.142\n"
             "       |        |        |  +- progtest AAAA 2001:718:2:2902:0:1:2:3\n"
             "       |        |        |  +- courses A 147.32.232.158\n"
             "       |        |        |  +- courses A 147.32.232.160\n"
             "       |        |        |  +- courses A 147.32.232.159\n"
             "       |        |        |  +- pririz CNAME sto.fit.cvut.cz.\n"
             "       |        |        |  +- courses SPF ip4:147.32.232.128/25, ip4:147.32.232.64/26\n"
             "       |        |        |  +- fel\n"
             "       |        |        |  |  +- www A 147.32.80.2\n"
             "       |        |        |  |  \\- www AAAA 1:2:3:4:5:6:7:8\n"
             "       |        |        |  \\- cz\n"
             "       |        |        |     \\- cvut\n"
             "       |        |        |        +- fit\n"
             "       |        |        |        |  +- progtest A 147.32.232.142\n"
             "       |        |        |        |  +- progtest AAAA 2001:718:2:2902:0:1:2:3\n"
             "       |        |        |        |  +- courses A 147.32.232.158\n"
             "       |        |        |        |  +- courses A 147.32.232.160\n"
             "       |        |        |        |  +- courses A 147.32.232.159\n"
             "       |        |        |        |  +- pririz CNAME sto.fit.cvut.cz.\n"
             "       |        |        |        |  +- courses SPF ip4:147.32.232.128/25, ip4:147.32.232.64/26\n"
             "       |        |        |        |  \\- fel\n"
             "       |        |        |        |     +- www A 147.32.80.2\n"
             "       |        |        |        |     \\- www AAAA 1:2:3:4:5:6:7:8\n"
             "       |        |        |        \\- fel\n"
             "       |        |        |           +- www A 147.32.80.2\n"
             "       |        |        |           \\- www AAAA 1:2:3:4:5:6:7:8\n"
             "       |        |        \\- fel\n"
             "       |        |           +- www A 147.32.80.2\n"
             "       |        |           \\- www AAAA 1:2:3:4:5:6:7:8\n"
             "       |        \\- fel\n"
             "       |           +- www A 147.32.80.2\n"
             "       |           \\- www AAAA 1:2:3:4:5:6:7:8\n"
             "       \\- fel\n"
             "          +- www A 147.32.80.2\n"
             "          \\- www AAAA 1:2:3:4:5:6:7:8\n" );
    CZone z25 ( z20 );
    z22 = z20;
    assert ( z20 . Add ( CZone ( "sk" ) ) == true );
    assert ( z25 . Add ( CZone ( "au" ) ) == true );
    assert ( z22 . Add ( CZone ( "de" ) ) == true );
    oss . str ( "" );
    oss << z20;
    assert ( oss . str () ==
             "<ROOT ZONE>\n"
             " +- cz\n"
             " |  \\- cvut\n"
             " |     +- fit\n"
             " |     |  +- progtest A 147.32.232.142\n"
             " |     |  +- progtest AAAA 2001:718:2:2902:0:1:2:3\n"
             " |     |  +- courses A 147.32.232.158\n"
             " |     |  +- courses A 147.32.232.160\n"
             " |     |  +- courses A 147.32.232.159\n"
             " |     |  +- pririz CNAME sto.fit.cvut.cz.\n"
             " |     |  +- courses SPF ip4:147.32.232.128/25, ip4:147.32.232.64/26\n"
             " |     |  +- fel\n"
             " |     |  |  +- www A 147.32.80.2\n"
             " |     |  |  \\- www AAAA 1:2:3:4:5:6:7:8\n"
             " |     |  \\- cz\n"
             " |     |     \\- cvut\n"
             " |     |        +- fit\n"
             " |     |        |  +- progtest A 147.32.232.142\n"
             " |     |        |  +- progtest AAAA 2001:718:2:2902:0:1:2:3\n"
             " |     |        |  +- courses A 147.32.232.158\n"
             " |     |        |  +- courses A 147.32.232.160\n"
             " |     |        |  +- courses A 147.32.232.159\n"
             " |     |        |  +- pririz CNAME sto.fit.cvut.cz.\n"
             " |     |        |  +- courses SPF ip4:147.32.232.128/25, ip4:147.32.232.64/26\n"
             " |     |        |  \\- cz\n"
             " |     |        |     \\- cvut\n"
             " |     |        |        +- fit\n"
             " |     |        |        |  +- progtest A 147.32.232.142\n"
             " |     |        |        |  +- progtest AAAA 2001:718:2:2902:0:1:2:3\n"
             " |     |        |        |  +- courses A 147.32.232.158\n"
             " |     |        |        |  +- courses A 147.32.232.160\n"
             " |     |        |        |  +- courses A 147.32.232.159\n"
             " |     |        |        |  +- pririz CNAME sto.fit.cvut.cz.\n"
             " |     |        |        |  +- courses SPF ip4:147.32.232.128/25, ip4:147.32.232.64/26\n"
             " |     |        |        |  +- fel\n"
             " |     |        |        |  |  +- www A 147.32.80.2\n"
             " |     |        |        |  |  \\- www AAAA 1:2:3:4:5:6:7:8\n"
             " |     |        |        |  \\- cz\n"
             " |     |        |        |     \\- cvut\n"
             " |     |        |        |        +- fit\n"
             " |     |        |        |        |  +- progtest A 147.32.232.142\n"
             " |     |        |        |        |  +- progtest AAAA 2001:718:2:2902:0:1:2:3\n"
             " |     |        |        |        |  +- courses A 147.32.232.158\n"
             " |     |        |        |        |  +- courses A 147.32.232.160\n"
             " |     |        |        |        |  +- courses A 147.32.232.159\n"
             " |     |        |        |        |  +- pririz CNAME sto.fit.cvut.cz.\n"
             " |     |        |        |        |  +- courses SPF ip4:147.32.232.128/25, ip4:147.32.232.64/26\n"
             " |     |        |        |        |  \\- fel\n"
             " |     |        |        |        |     +- www A 147.32.80.2\n"
             " |     |        |        |        |     \\- www AAAA 1:2:3:4:5:6:7:8\n"
             " |     |        |        |        \\- fel\n"
             " |     |        |        |           +- www A 147.32.80.2\n"
             " |     |        |        |           \\- www AAAA 1:2:3:4:5:6:7:8\n"
             " |     |        |        \\- fel\n"
             " |     |        |           +- www A 147.32.80.2\n"
             " |     |        |           \\- www AAAA 1:2:3:4:5:6:7:8\n"
             " |     |        \\- fel\n"
             " |     |           +- www A 147.32.80.2\n"
             " |     |           \\- www AAAA 1:2:3:4:5:6:7:8\n"
             " |     \\- fel\n"
             " |        +- www A 147.32.80.2\n"
             " |        \\- www AAAA 1:2:3:4:5:6:7:8\n"
             " \\- sk\n" );
    oss . str ( "" );
    oss << z22;
    assert ( oss . str () ==
             "<ROOT ZONE>\n"
             " +- cz\n"
             " |  \\- cvut\n"
             " |     +- fit\n"
             " |     |  +- progtest A 147.32.232.142\n"
             " |     |  +- progtest AAAA 2001:718:2:2902:0:1:2:3\n"
             " |     |  +- courses A 147.32.232.158\n"
             " |     |  +- courses A 147.32.232.160\n"
             " |     |  +- courses A 147.32.232.159\n"
             " |     |  +- pririz CNAME sto.fit.cvut.cz.\n"
             " |     |  +- courses SPF ip4:147.32.232.128/25, ip4:147.32.232.64/26\n"
             " |     |  +- fel\n"
             " |     |  |  +- www A 147.32.80.2\n"
             " |     |  |  \\- www AAAA 1:2:3:4:5:6:7:8\n"
             " |     |  \\- cz\n"
             " |     |     \\- cvut\n"
             " |     |        +- fit\n"
             " |     |        |  +- progtest A 147.32.232.142\n"
             " |     |        |  +- progtest AAAA 2001:718:2:2902:0:1:2:3\n"
             " |     |        |  +- courses A 147.32.232.158\n"
             " |     |        |  +- courses A 147.32.232.160\n"
             " |     |        |  +- courses A 147.32.232.159\n"
             " |     |        |  +- pririz CNAME sto.fit.cvut.cz.\n"
             " |     |        |  +- courses SPF ip4:147.32.232.128/25, ip4:147.32.232.64/26\n"
             " |     |        |  \\- cz\n"
             " |     |        |     \\- cvut\n"
             " |     |        |        +- fit\n"
             " |     |        |        |  +- progtest A 147.32.232.142\n"
             " |     |        |        |  +- progtest AAAA 2001:718:2:2902:0:1:2:3\n"
             " |     |        |        |  +- courses A 147.32.232.158\n"
             " |     |        |        |  +- courses A 147.32.232.160\n"
             " |     |        |        |  +- courses A 147.32.232.159\n"
             " |     |        |        |  +- pririz CNAME sto.fit.cvut.cz.\n"
             " |     |        |        |  +- courses SPF ip4:147.32.232.128/25, ip4:147.32.232.64/26\n"
             " |     |        |        |  +- fel\n"
             " |     |        |        |  |  +- www A 147.32.80.2\n"
             " |     |        |        |  |  \\- www AAAA 1:2:3:4:5:6:7:8\n"
             " |     |        |        |  \\- cz\n"
             " |     |        |        |     \\- cvut\n"
             " |     |        |        |        +- fit\n"
             " |     |        |        |        |  +- progtest A 147.32.232.142\n"
             " |     |        |        |        |  +- progtest AAAA 2001:718:2:2902:0:1:2:3\n"
             " |     |        |        |        |  +- courses A 147.32.232.158\n"
             " |     |        |        |        |  +- courses A 147.32.232.160\n"
             " |     |        |        |        |  +- courses A 147.32.232.159\n"
             " |     |        |        |        |  +- pririz CNAME sto.fit.cvut.cz.\n"
             " |     |        |        |        |  +- courses SPF ip4:147.32.232.128/25, ip4:147.32.232.64/26\n"
             " |     |        |        |        |  \\- fel\n"
             " |     |        |        |        |     +- www A 147.32.80.2\n"
             " |     |        |        |        |     \\- www AAAA 1:2:3:4:5:6:7:8\n"
             " |     |        |        |        \\- fel\n"
             " |     |        |        |           +- www A 147.32.80.2\n"
             " |     |        |        |           \\- www AAAA 1:2:3:4:5:6:7:8\n"
             " |     |        |        \\- fel\n"
             " |     |        |           +- www A 147.32.80.2\n"
             " |     |        |           \\- www AAAA 1:2:3:4:5:6:7:8\n"
             " |     |        \\- fel\n"
             " |     |           +- www A 147.32.80.2\n"
             " |     |           \\- www AAAA 1:2:3:4:5:6:7:8\n"
             " |     \\- fel\n"
             " |        +- www A 147.32.80.2\n"
             " |        \\- www AAAA 1:2:3:4:5:6:7:8\n"
             " \\- de\n" );
    oss . str ( "" );
    oss << z25;
    assert ( oss . str () ==
             "<ROOT ZONE>\n"
             " +- cz\n"
             " |  \\- cvut\n"
             " |     +- fit\n"
             " |     |  +- progtest A 147.32.232.142\n"
             " |     |  +- progtest AAAA 2001:718:2:2902:0:1:2:3\n"
             " |     |  +- courses A 147.32.232.158\n"
             " |     |  +- courses A 147.32.232.160\n"
             " |     |  +- courses A 147.32.232.159\n"
             " |     |  +- pririz CNAME sto.fit.cvut.cz.\n"
             " |     |  +- courses SPF ip4:147.32.232.128/25, ip4:147.32.232.64/26\n"
             " |     |  +- fel\n"
             " |     |  |  +- www A 147.32.80.2\n"
             " |     |  |  \\- www AAAA 1:2:3:4:5:6:7:8\n"
             " |     |  \\- cz\n"
             " |     |     \\- cvut\n"
             " |     |        +- fit\n"
             " |     |        |  +- progtest A 147.32.232.142\n"
             " |     |        |  +- progtest AAAA 2001:718:2:2902:0:1:2:3\n"
             " |     |        |  +- courses A 147.32.232.158\n"
             " |     |        |  +- courses A 147.32.232.160\n"
             " |     |        |  +- courses A 147.32.232.159\n"
             " |     |        |  +- pririz CNAME sto.fit.cvut.cz.\n"
             " |     |        |  +- courses SPF ip4:147.32.232.128/25, ip4:147.32.232.64/26\n"
             " |     |        |  \\- cz\n"
             " |     |        |     \\- cvut\n"
             " |     |        |        +- fit\n"
             " |     |        |        |  +- progtest A 147.32.232.142\n"
             " |     |        |        |  +- progtest AAAA 2001:718:2:2902:0:1:2:3\n"
             " |     |        |        |  +- courses A 147.32.232.158\n"
             " |     |        |        |  +- courses A 147.32.232.160\n"
             " |     |        |        |  +- courses A 147.32.232.159\n"
             " |     |        |        |  +- pririz CNAME sto.fit.cvut.cz.\n"
             " |     |        |        |  +- courses SPF ip4:147.32.232.128/25, ip4:147.32.232.64/26\n"
             " |     |        |        |  +- fel\n"
             " |     |        |        |  |  +- www A 147.32.80.2\n"
             " |     |        |        |  |  \\- www AAAA 1:2:3:4:5:6:7:8\n"
             " |     |        |        |  \\- cz\n"
             " |     |        |        |     \\- cvut\n"
             " |     |        |        |        +- fit\n"
             " |     |        |        |        |  +- progtest A 147.32.232.142\n"
             " |     |        |        |        |  +- progtest AAAA 2001:718:2:2902:0:1:2:3\n"
             " |     |        |        |        |  +- courses A 147.32.232.158\n"
             " |     |        |        |        |  +- courses A 147.32.232.160\n"
             " |     |        |        |        |  +- courses A 147.32.232.159\n"
             " |     |        |        |        |  +- pririz CNAME sto.fit.cvut.cz.\n"
             " |     |        |        |        |  +- courses SPF ip4:147.32.232.128/25, ip4:147.32.232.64/26\n"
             " |     |        |        |        |  \\- fel\n"
             " |     |        |        |        |     +- www A 147.32.80.2\n"
             " |     |        |        |        |     \\- www AAAA 1:2:3:4:5:6:7:8\n"
             " |     |        |        |        \\- fel\n"
             " |     |        |        |           +- www A 147.32.80.2\n"
             " |     |        |        |           \\- www AAAA 1:2:3:4:5:6:7:8\n"
             " |     |        |        \\- fel\n"
             " |     |        |           +- www A 147.32.80.2\n"
             " |     |        |           \\- www AAAA 1:2:3:4:5:6:7:8\n"
             " |     |        \\- fel\n"
             " |     |           +- www A 147.32.80.2\n"
             " |     |           \\- www AAAA 1:2:3:4:5:6:7:8\n"
             " |     \\- fel\n"
             " |        +- www A 147.32.80.2\n"
             " |        \\- www AAAA 1:2:3:4:5:6:7:8\n"
             " \\- au\n" );

    return 0;
}
#endif /* __PROGTEST__ */
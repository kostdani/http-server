#ifndef __PROGTEST__
#include <cassert>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <iostream>
#include <iomanip>
#include <string>
#include <memory>
#include <functional>
#include <vector>
#include <algorithm>
using namespace std;
#endif /* __PROGTEST__ */


class CPerson{
public:
    string name;
    string surname;
    unsigned int carnum;
    CPerson(const string &nm,const string &sn ):name(nm),surname(sn){carnum=1;}
    CPerson(const CPerson &orig):name(orig.name),surname(orig.surname){carnum=orig.carnum;}

    bool operator == (const CPerson &x) const{
        return (name==x.name&&surname==x.surname);
    }
    bool operator < (const CPerson &x) const{
        int c=surname.compare(x.surname);
        if(c<0)
            return true;
        if(!c){
            c=name.compare(x.name);
            if(c<0)
                return true;
        }
        return false;
    }
    bool operator > (const CPerson &x)const{
        return x<(*this);
    }
};
class CRecord{
public:
    string RZ;
    CPerson owner;
    CRecord(const string & rz, const CPerson& own):RZ(rz),owner(own){}
    CRecord(const CRecord& orig):RZ(orig.RZ),owner(orig.owner){}
    bool operator == ( const CRecord &sec) const{return RZ==sec.RZ;}
    bool operator < ( const CRecord &sec) const{return RZ<sec.RZ;}
    bool operator > ( const CRecord &sec) const{return RZ>sec.RZ;}
};

template <typename DT>
class MySet{
private:
    unsigned int recFind(DT value,unsigned int start,unsigned int end) const{
        if(start==end) {
            //return start;
            if (array[start] < value)
                return start+1;
            else
                return start;
        }else{
            unsigned int mid=(start+end)/2;
            if (array[mid] == value)
                return mid;
            else if(value < array[mid])
                return recFind(value,start,mid);
            else
                return recFind(value,mid+1,end);

        }


    }

public:
    vector<DT> array;
    void Insert(DT value){
        array.push_back(value);//somnitelno
        for (int i = array.size()-1; i >0 ; --i) {
            if(array[i-1]>value){
                array[i]=array[i-1];
            }else{
                array[i]=value;
                return;
            }
        }
        array[0]=value;
        return;
    }
    unsigned int Find(DT value) const{
        if(!array.size())
            return 0;
        return recFind(value,0,array.size()-1);
    }
    void Remove(unsigned int pos){
        while (pos!=(array.size()-1)){
            array[pos]=array[pos+1];
            pos++;
        }
        array.pop_back();

    }

};


class CCarList
{
public:
    CCarList(const MySet<CRecord> *ptr, int starti){
        set=ptr;
        i=starti;
    }
    const string & RZ      ( void ) const{
        return set->array[i].RZ;
    }
    bool           AtEnd   ( void ) const{
        return i>=set->array.size();
    }
    void           Next    ( void ){
        int oldi=i;

        while (!AtEnd()){
            i++;
            if(AtEnd())
                return;
            if(set->array[i].owner==set->array[oldi].owner)
                return;
        }
    }
private:
    const MySet<CRecord> *set;
    unsigned int i;
    // todo
};

class CPersonList
{
public:
    CPersonList(const MySet<CPerson> *ptr){
        set=ptr;
        i=0;
    }
    const string & Name    ( void ) const{
        return set->array[i].name;
    }
    const string & Surname ( void ) const{
        return set->array[i].surname;
    }
    bool           AtEnd   ( void ) const{
        return i>=set->array.size();
    }
    void           Next    ( void ){
        if(!AtEnd())
            i++;
    }
private:
    const MySet<CPerson> *set;
    unsigned int i;
    // todo
};

class CRegister
{
public:
    CRegister  ( void ){}
    ~CRegister  ( void ){}
    CRegister  ( const CRegister & src ) = delete;
    CRegister & operator = ( const CRegister & src ) = delete;
    bool        AddCar     ( const string & rz,
                             const string & name,
                             const string & surname ){
        CPerson newOwner(name,surname);
        CRecord newRecord(rz,newOwner);
        int i=records.Find(newRecord);
        if(i<(int)records.array.size()&& records.array[i]==newRecord)
            return false;
        records.Insert(newRecord);
        i=owners.Find(newOwner);
        if(i<(int)owners.array.size()&&owners.array[i]==newOwner){
            owners.array[i].carnum++;
        }else{
            owners.Insert(newOwner);
        }
        return true;
    }
    bool        DelCar     ( const string & rz ){
        CRecord rmRecord(rz,CPerson("",""));
        int i=records.Find(rmRecord);
        if(i>=(int)records.array.size()|| records.array[i].RZ!=rz)
            return false;
        CPerson rmOwner=records.array[i].owner;
        records.Remove(i);
        i=owners.Find(rmOwner);

        if(i<(int)owners.array.size()&&owners.array[i]==rmOwner){
            owners.array[i].carnum--;
            if(!owners.array[i].carnum)
                owners.Remove(i);
        }
        return true;
    }
    bool        Transfer   ( const string & rz,
                             const string & nName,
                             const string & nSurname){
        CPerson newOwner(nName,nSurname);
        CRecord newRecord(rz,newOwner);
        int i=records.Find(newRecord);
        if(i>=(int)records.array.size()|| records.array[i].RZ!=rz)
            return false;
        CPerson oldOwner=records.array[i].owner;
        if(newOwner==oldOwner)
            return false;
        records.array[i].owner=newOwner;

        i=owners.Find(oldOwner);
        if(i<(int)owners.array.size()&&owners.array[i]==oldOwner){
            owners.array[i].carnum--;
            if(!owners.array[i].carnum)
                owners.Remove(i);
        }

        i=owners.Find(newOwner);
        if(i<(int)owners.array.size()&&owners.array[i]==newOwner){
            owners.array[i].carnum++;
        }else{
            owners.Insert(newOwner);
        }
        return true;

    }
    CCarList    ListCars   ( const string & name,
                             const string & surname ) const{
        if(!CountCars(name,surname))
            return CCarList(&records,records.array.size());
        CPerson apers(name,surname);
        for (int i = 0; i < (int)records.array.size(); ++i) {
            if(records.array[i].owner==apers)
                return CCarList(&records,i);
        }
        return CCarList(&records,records.array.size());

    }
    int         CountCars  ( const string & name,
                             const string & surname ) const{

        int i=owners.Find(CPerson(name,surname));
        if(i<(int)owners.array.size()&&owners.array[i].name==name&&owners.array[i].surname==surname)
            return owners.array[i].carnum;
        return 0;
    }
    CPersonList ListPersons( void ) const{
        //CPersonList t(&owners);
        return CPersonList(&owners);
    }
private:
    MySet<CPerson> owners;
    MySet<CRecord> records;
    // todo
};

#ifndef __PROGTEST__
bool checkPerson           ( CRegister    & r,
                             const string & name,
                             const string & surname,
                             vector<string> result )
{
    for ( CCarList l = r . ListCars ( name, surname ); ! l . AtEnd (); l . Next () )
    {
        auto pos = find ( result . begin (), result . end (), l . RZ () );
        if ( pos == result . end () )
            return false;
        result . erase ( pos );
    }
    return result . size () == 0;
}
int main ( void )
{
   // auto b=s.Find(6);

    CRegister b1;
    //b1 . AddCar ( "ABC-12-34", "John", "Smith" );
     assert ( b1 . AddCar ( "ABC-12-34", "John", "Smith" ) == true );
    assert ( b1 . AddCar ( "ABC-32-22", "John", "Hacker" ) == true );
    assert ( b1 . AddCar ( "XYZ-11-22", "Peter", "Smith" ) == true );
    assert ( b1 . CountCars ( "John", "Hacker" ) == 1 );
    assert ( checkPerson ( b1, "John", "Hacker", { "ABC-32-22" } ) );
    assert ( b1 . Transfer ( "XYZ-11-22", "John", "Hacker" ) == true );
    assert ( b1 . AddCar ( "XYZ-99-88", "John", "Smith" ) == true );
    assert ( b1 . CountCars ( "John", "Smith" ) == 2 );
    return 0;
    /*
    auto l = b1.ListPersons();
    while (!l.AtEnd()){
        cout<<l.Name()<<" "<<l.Surname()<<":"<<endl;
        auto l1=b1.ListCars(l.Name(),l.Surname());
        while (!l1.AtEnd()){
            cout<<l1.RZ()<<endl;
            l1.Next();
        }
        l.Next();
    }*/

    assert ( checkPerson ( b1, "John", "Smith", { "ABC-12-34", "XYZ-99-88" } ) );
    assert ( b1 . CountCars ( "John", "Hacker" ) == 2 );
    assert ( checkPerson ( b1, "John", "Hacker", { "ABC-32-22", "XYZ-11-22" } ) );
    assert ( b1 . CountCars ( "Peter", "Smith" ) == 0 );
    assert ( checkPerson ( b1, "Peter", "Smith", {  } ) );
    assert ( b1 . Transfer ( "XYZ-11-22", "Jane", "Black" ) == true );
    assert ( b1 . CountCars ( "Jane", "Black" ) == 1 );
    assert ( checkPerson ( b1, "Jane", "Black", { "XYZ-11-22" } ) );
    assert ( b1 . CountCars ( "John", "Smith" ) == 2 );
    assert ( checkPerson ( b1, "John", "Smith", { "ABC-12-34", "XYZ-99-88" } ) );
    assert ( b1 . DelCar ( "XYZ-11-22" ) == true );
    assert ( b1 . CountCars ( "Jane", "Black" ) == 0 );
    assert ( checkPerson ( b1, "Jane", "Black", {  } ) );
    assert ( b1 . AddCar ( "XYZ-11-22", "George", "White" ) == true );
    CPersonList i1 = b1 . ListPersons ();
    assert ( ! i1 . AtEnd () && i1 . Surname () == "Hacker" && i1 . Name () == "John" );
    assert ( checkPerson ( b1, "John", "Hacker", { "ABC-32-22" } ) );
    i1 . Next ();
    assert ( ! i1 . AtEnd () && i1 . Surname () == "Smith" && i1 . Name () == "John" );
    assert ( checkPerson ( b1, "John", "Smith", { "ABC-12-34", "XYZ-99-88" } ) );
    i1 . Next ();
    assert ( ! i1 . AtEnd () && i1 . Surname () == "White" && i1 . Name () == "George" );
    assert ( checkPerson ( b1, "George", "White", { "XYZ-11-22" } ) );
    i1 . Next ();
    assert ( i1 . AtEnd () );

    CRegister b2;
    assert ( b2 . AddCar ( "ABC-12-34", "John", "Smith" ) == true );
    assert ( b2 . AddCar ( "ABC-32-22", "John", "Hacker" ) == true );
    assert ( b2 . AddCar ( "XYZ-11-22", "Peter", "Smith" ) == true );
    assert ( b2 . AddCar ( "XYZ-11-22", "Jane", "Black" ) == false );
    assert ( b2 . DelCar ( "AAA-11-11" ) == false );
    assert ( b2 . Transfer ( "BBB-99-99", "John", "Smith" ) == false );
    assert ( b2 . Transfer ( "ABC-12-34", "John", "Smith" ) == false );
    assert ( b2 . CountCars ( "George", "White" ) == 0 );
    assert ( checkPerson ( b2, "George", "White", {  } ) );
    CPersonList i2 = b2 . ListPersons ();
    assert ( ! i2 . AtEnd () && i2 . Surname () == "Hacker" && i2 . Name () == "John" );
    assert ( checkPerson ( b2, "John", "Hacker", { "ABC-32-22" } ) );
    i2 . Next ();
    assert ( ! i2 . AtEnd () && i2 . Surname () == "Smith" && i2 . Name () == "John" );
    assert ( checkPerson ( b2, "John", "Smith", { "ABC-12-34" } ) );
    i2 . Next ();
    assert ( ! i2 . AtEnd () && i2 . Surname () == "Smith" && i2 . Name () == "Peter" );
    assert ( checkPerson ( b2, "Peter", "Smith", { "XYZ-11-22" } ) );
    i2 . Next ();
    assert ( i2 . AtEnd () );

    return 0;
}
#endif /* __PROGTEST__ */

#ifndef __PROGTEST__
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cstdint>
#include <cassert>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include <vector>
using namespace std;

const uint32_t BIG_ENDIAN_ID    = 0x4d6d6d4d;
const uint32_t LITTLE_ENDIAN_ID = 0x49696949;
const uint32_t FRAME_ID         = 0x46727246;
const uint32_t VIDEO_DATA_ID    = 0x56696956;
const uint32_t AUDIO_LIST_ID    = 0x416c6c41;
const uint32_t AUDIO_DATA_ID    = 0x41757541;
#endif /* __PROGTEST__ */

class fileWrapper{
private:
public:
    ofstream outfile;
    ifstream file;
    uint32_t end;
    bool eof;
    bool fail;
    bool open_input(const char * FileName){
        file.open(FileName);
        end = 0;
        eof=0;
        end = this->next4bites();
        if((file.is_open())&&((end==BIG_ENDIAN_ID)||(end==LITTLE_ENDIAN_ID)))
            return true;
        return false;
    }
    void close(){
        if(file.is_open())
            file.close();
        if(outfile.is_open())
            outfile.close();
    }
    bool open_output(const char * FileName){
        outfile.open(FileName);
        if(outfile.is_open())
            return true;
        return false;
    }
    uint8_t nextbite(){
        uint8_t r=file.get();
        if(file.eof()){
            eof=1;
        }
        return r;
    }
    uint16_t next2bites(){
        uint16_t r=0;
        for (int i = 0; i < 2; ++i) {
            uint16_t d= nextbite();

            r+=(d<<(8*i));
        }
        return r;
    }
    uint32_t next4bites(){
        if(end==LITTLE_ENDIAN_ID)
            return little_next4bites();
        else
            return big_next4bites();
    }
    uint32_t little_next4bites(){
        uint32_t r=0;
        for (int i = 0; i < 4; ++i) {
            uint32_t d= nextbite();

            r+=(d<<(8*i));
            //cout<<d<<" ";
        }
        //cout<<endl;
        return r;
    }
    uint32_t big_next4bites(){
        uint32_t r=0;
        for (int i = 3; i >= 0; --i) {
            uint32_t d= nextbite();
            r+=(d<<(8*i));
            //cout<<d<<" ";
        }
        //cout<<endl;
        return r;
    }
    void writenext2bites(uint16_t samp){
        for (int i = 0; i < 2; ++i) {
            uint8_t ch= (uint8_t)(samp>>(8*i));
            outfile.put(ch);
            //cout<<(int)ch<<" ";
        }
        //cout<<endl;
    }
    void writenext4bites(uint32_t samp){
        if(end==LITTLE_ENDIAN_ID)
            little_writenext4bites(samp);
        else{
            big_writenext4bites(samp);
        }
    }
    void little_writenext4bites(uint32_t samp){
        for (int i = 0; i < 4; ++i) {
            uint8_t ch= (uint8_t)(samp>>(8*i));
            outfile.put(ch);
            //cout<<(int)ch<<" ";
        }
        //cout<<endl;
    }
    void big_writenext4bites(uint32_t samp){
        for (int i = 3; i >= 0; --i) {
            uint8_t ch= (uint8_t)(samp>>(8*i));
            outfile.put(ch);
            //cout<<(int)ch<<" ";
        }
        //cout<<endl;
    }
    void copynbites(uint32_t n){
        for (uint32_t i = 0; i < n; ++i) {
            uint8_t ch= file.get();
            outfile.put(ch);
            //cout<<hex<<(int)ch<<" ";
        }
        //cout<<endl;
    }
    void skipnbites(uint32_t n){
        for (uint32_t i = 0; i < n; ++i) {
            file.get();
            //cout<<file.get()<<" ";
        }
        //cout<<endl;
    }
};

struct Frame{
    uint32_t length;
    uint32_t audio_length;
};

class Record{
private:
    uint32_t length;
    uint16_t lang;
    vector<Frame> frames;
public:
    fileWrapper wrapper;
    Record(const char *lang){
        this->lang=((uint16_t)lang[1]<<8)+lang[0];
    }
    int scanFrame(){
        Frame newFrame;
        uint32_t id=wrapper.next4bites();
        if(id!=FRAME_ID) {
            return 0;
        }
        newFrame.length=wrapper.next4bites();
        id=wrapper.next4bites();
        if(id!=VIDEO_DATA_ID)
            return 0;
        uint32_t video_length;
        video_length=wrapper.next4bites();
        wrapper.skipnbites(video_length+4);
        id=wrapper.next4bites();
        if(id!=AUDIO_LIST_ID)
            return 0;

        uint32_t audionum=wrapper.next4bites();
        uint32_t actual_audio_length=0;
        newFrame.audio_length=wrapper.next4bites();
        for (uint32_t i = 0; i < audionum; ++i) {
            id=wrapper.next4bites();
            if(id!=AUDIO_DATA_ID)
                return 0;
            uint16_t l=wrapper.next2bites();
            if(lang==l){
                uint32_t audio_length=wrapper.next4bites();
                actual_audio_length+=(audio_length+14);
                wrapper.skipnbites(audio_length+4);

            }else{
                uint32_t audio_length=wrapper.next4bites();
                newFrame.audio_length-=(audio_length+14);
                newFrame.length-=(audio_length+14);
                length-=(audio_length+14);
                wrapper.skipnbites(audio_length+4);
            }
        }
        wrapper.next4bites();
        wrapper.next4bites();
        //cout<<"audiolength expected "<<newFrame.audio_length<<" got "<<actual_audio_length<<endl;
        if(newFrame.audio_length!=actual_audio_length){
            return 0;
        }
        uint32_t actual_frame_length = video_length+actual_audio_length+28;
        //cout<<"frame expected "<<newFrame.length<<" got "<<actual_frame_length<<endl;
        if(newFrame.length!=actual_frame_length){
            return 0;
        }
        frames.push_back(newFrame);
        return actual_frame_length+12;
        //cout<<vlen<<endl;
    }
    bool scan(const char      * srcFileName){
        if(!wrapper.open_input(srcFileName))
            return false;
        if(wrapper.end==LITTLE_ENDIAN_ID){
           // cout<<"Little endian\n";
        }else if(wrapper.end==BIG_ENDIAN_ID){
           // cout<<"Big endian\n";
        }else{
            return false;
        }

        uint32_t framenum=wrapper.next4bites();
        //cout<<"Num of frames: "<<framenum<<endl;
        length=wrapper.next4bites();

        //cout<<"endianess: "<<endianess;
    uint32_t actual_length=0;
        for (uint32_t i = 0; i < framenum; ++i) {
            uint32_t t = scanFrame();
            if(t)
                actual_length+=t;
            else
                return false;
            if(actual_length>length)
                return false;
        }
        //cout<<"record expected "<<length<<" got "<<actual_length<<endl;
        if(length!=actual_length){
            return 0;
        }
        wrapper.next4bites();
        if(wrapper.eof){
            return false;
        }
        wrapper.nextbite();
        if(!wrapper.eof){
            return false;
        }
        wrapper.close();

        return 1;
    }
    bool write( const char      * srcFileName, const char      * dstFileName){
        wrapper.open_input(srcFileName);
        if(!wrapper.open_output(dstFileName)){
            return false;
        }

        wrapper.writenext4bites(wrapper.end);
        wrapper.copynbites(4);
        wrapper.writenext4bites(length);
        uint32_t l= wrapper.next4bites();
        if(length==l){
            wrapper.copynbites(length+4);
            wrapper.close();
            if(!wrapper.outfile)
                return false;
            return true;
        }
        for(Frame frame : frames){
            wrapper.copynbites(4);
            l= wrapper.next4bites();
            wrapper.writenext4bites(frame.length);
            if(frame.length==l){
                wrapper.copynbites(frame.length+4);
                continue;
            }
            //videodata
            wrapper.copynbites(4);
            l= wrapper.next4bites();
            wrapper.writenext4bites(l);
            wrapper.copynbites(l+4);
            //audolist
            wrapper.copynbites(4);
            if(!frame.audio_length){
                wrapper.writenext4bites(0);
                wrapper.writenext4bites(0);
                wrapper.writenext4bites(0);
                wrapper.writenext4bites(0);
                wrapper.next4bites();
                l=wrapper.next4bites();
                //cout<<l<<endl;
                wrapper.skipnbites(l+8);
            }else{
                wrapper.writenext4bites(1);
                wrapper.writenext4bites(frame.audio_length);
                wrapper.writenext4bites(AUDIO_DATA_ID);
                wrapper.writenext2bites(lang);
                uint32_t audionum=wrapper.next4bites();
                wrapper.next4bites();
                for (uint32_t i = 0; i < audionum; ++i) {
                    wrapper.next4bites();
                    if(wrapper.next2bites()==lang){
                        l=wrapper.next4bites();
                        wrapper.writenext4bites(l);
                        wrapper.copynbites(l+4);
                    }else{
                        l=wrapper.next4bites();
                        wrapper.skipnbites(l+4);

                    }
                }
                //audiolist crx
                wrapper.writenext4bites(0);
                //frame crx
                wrapper.writenext4bites(0);
                wrapper.skipnbites(8);
            }

        }
        wrapper.writenext4bites(0);
        wrapper.close();
        if(!wrapper.outfile){
            return false;
        }
        return true;
    }
};
bool  filterFile          ( const char      * srcFileName,
                            const char      * dstFileName,
                            const char      * lang ){
    Record rec(lang);
    if(!rec.scan(srcFileName)){
        rec.wrapper.close();
        return false;
    }

    return rec.write(srcFileName,dstFileName);
}
int main(){
    cout<<filterFile("in_0000.in","myout0","cs")<<endl;
    cout<<filterFile("in_0001.in","myout1","cs")<<endl;
    cout<<filterFile("in_0002.in","myout2","en")<<endl;
    cout<<filterFile("in_0003.in","myout3","en")<<endl;
    cout<<filterFile("in_0004.in","myout4","pl")<<endl;
    cout<<filterFile("in_0005.in","myout5","cs")<<endl;
    cout<<filterFile("in_0006.in","myout6","cs")<<endl;
    return 0;
}
